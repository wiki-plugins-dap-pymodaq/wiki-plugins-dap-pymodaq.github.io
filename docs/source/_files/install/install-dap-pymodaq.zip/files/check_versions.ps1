# Compare la version locale de chaque plugin (files\<dossier>\version.json) a la
# derniere version publiee sur PyPI. Appele par Install.bat. Une ligne par plugin :
#   CLE|version locale (? si absente)|version PyPI (- si injoignable)|1 si PyPI est plus recente, sinon 0
param([string]$PypiBase = 'https://pypi.org/pypi')

$plugins = @(
    @{ Key = 'RASP';    Folder = 'pymodaq_plugins_raspberry'; Name = 'pymodaq_plugins_raspberry' },
    @{ Key = 'ARDUINO'; Folder = 'pymodaq-plugins-arduino';   Name = 'pymodaq_plugins_arduino' }
)

function Get-VersionKey([string]$version) {
    # Cle de comparaison PEP 440 simplifiee : 4 nombres, puis dev < a < b < rc < finale < post
    if ($version -notmatch '^(\d+(?:\.\d+)*)(.*)$') { return $null }
    $release = @($Matches[1].Split('.') | ForEach-Object { [int]$_ })
    while ($release.Count -lt 4) { $release += 0 }
    $suffix = $Matches[2]
    $rank = if ($suffix -match 'dev') { -1 } elseif ($suffix -match 'rc') { 2 } elseif ($suffix -match 'b') { 1 } `
            elseif ($suffix -match 'a') { 0 } elseif ($suffix -match 'post') { 4 } else { 3 }
    return @($release[0..3]) + $rank
}

function Test-Newer([string]$candidate, [string]$reference) {
    $c = Get-VersionKey $candidate
    $r = Get-VersionKey $reference
    if ($null -eq $c -or $null -eq $r) { return $false }
    for ($i = 0; $i -lt $c.Count; $i++) {
        if ($c[$i] -gt $r[$i]) { return $true }
        if ($c[$i] -lt $r[$i]) { return $false }
    }
    return $false
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
foreach ($plugin in $plugins) {
    $local = '?'
    try { $local = (Get-Content (Join-Path $plugin.Folder 'version.json') -Raw | ConvertFrom-Json).version } catch {}
    $pypi = '-'
    try { $pypi = (Invoke-RestMethod -Uri "$PypiBase/$($plugin.Name)/json" -TimeoutSec 5).info.version } catch {}
    $newer = if ($pypi -ne '-' -and (Test-Newer $pypi $local)) { 1 } else { 0 }
    Write-Output "$($plugin.Key)|$local|$pypi|$newer"
}
