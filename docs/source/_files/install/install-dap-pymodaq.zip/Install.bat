@echo off
REM ============================================================
REM  Installation des plugins PyMoDAQ DAP (Raspberry unifie + Arduino)
REM  Lancable par double-clic. Les elements sont dans le sous-dossier "files".
REM ============================================================
setlocal

REM Se placer dans le sous-dossier "files" (a cote de ce .bat)
cd /d "%~dp0files"

set "DO_ENV=1"
set "DO_RASP=1"
set "DO_ARDUINO=1"
set "DO_CFG=1"
set "DO_CFGTEST="
set "DO_PRESET=1"

REM Versions des plugins : copie locale (files\...\version.json) et PyPI.
REM La copie locale est toujours la source par defaut : c'est la version testee
REM avec les presets et les configurations de ce package.
echo Verification des versions des plugins sur PyPI...
set "PYPI_ARG="
if defined DAP_PYPI_BASE set "PYPI_ARG=-PypiBase %DAP_PYPI_BASE%"
for /f "usebackq tokens=1-4 delims=|" %%A in (`powershell -NoProfile -ExecutionPolicy Bypass -File "check_versions.ps1" %PYPI_ARG%`) do (
    set "LOCAL_%%A=%%B"
    set "PYPI_%%A=%%C"
    set "NEWER_%%A="
    if "%%D"=="1" set "NEWER_%%A=1"
)
set "SRC_RASP=LOCAL"
set "SRC_ARDUINO=LOCAL"

:menu
cls
call :mark ENV
call :mark RASP
call :mark ARDUINO
call :mark CFG
call :mark CFGTEST
call :mark PRESET
call :srctext RASP
call :srctext ARDUINO
echo ================================================================
echo    INSTALLATION - Selection des actions
echo ================================================================
echo.
echo    1. [%S_ENV%]  Installer l'environnement Py26
echo    2. [%S_RASP%]  Installer le plugin Raspberry  -^> %T_RASP%
if defined NEWER_RASP echo          R. Changer la source Raspberry : locale %LOCAL_RASP% ou PyPI %PYPI_RASP%
echo    3. [%S_ARDUINO%]  Installer le plugin Arduino    -^> %T_ARDUINO%
if defined NEWER_ARDUINO echo          D. Changer la source Arduino : locale %LOCAL_ARDUINO% ou PyPI %PYPI_ARDUINO%
echo    4. [%S_CFG%]  Copier les fichiers de configuration (.toml)
echo    5. [%S_CFGTEST%]  ... avec le TOML Raspberry de test (simulation sur ce PC, 127.0.0.1)
echo    6. [%S_PRESET%]  Copier les fichiers de preset (.xml)
echo.
echo    A. Tout selectionner       N. Tout deselectionner
echo    G. Lancer                  Q. Quitter
echo.
set "choix="
set /p "choix=Numero pour (de)cocher, puis G pour lancer : "
if not defined choix goto menu
if /i "%choix%"=="1" ( call :toggle ENV & goto menu )
if /i "%choix%"=="2" ( call :toggle RASP & goto menu )
if /i "%choix%"=="3" ( call :toggle ARDUINO & goto menu )
if /i "%choix%"=="4" ( call :toggle CFG & goto menu )
if /i "%choix%"=="5" ( call :toggle CFGTEST & goto menu )
if /i "%choix%"=="6" ( call :toggle PRESET & goto menu )
if /i "%choix%"=="R" ( call :togglesrc RASP & goto menu )
if /i "%choix%"=="D" ( call :togglesrc ARDUINO & goto menu )
if /i "%choix%"=="A" ( call :selectall 1 & goto menu )
if /i "%choix%"=="N" ( call :selectall & goto menu )
if /i "%choix%"=="G" goto run
if /i "%choix%"=="Q" goto :eof
goto menu

:run
cls
REM Le TOML de test remplace le TOML d'exemple : il implique la copie des configurations
if defined DO_CFGTEST set "DO_CFG=1"

set "ANY="
for %%F in (ENV RASP ARDUINO CFG PRESET) do if defined DO_%%F set "ANY=1"
if not defined ANY ( echo Aucune action selectionnee. & pause & goto :eof )

set "NEED_DASH="
if defined DO_CFG    if not exist "%USERPROFILE%\.pymodaq" set "NEED_DASH=1"
if defined DO_PRESET if not exist "C:\ProgramData\.pymodaq" set "NEED_DASH=1"

set "WANT_COPY="
if defined DO_CFG set "WANT_COPY=1"
if defined DO_PRESET set "WANT_COPY=1"

set "NEED_CONDA="
if defined DO_ENV set "NEED_CONDA=1"
if defined DO_RASP set "NEED_CONDA=1"
if defined DO_ARDUINO set "NEED_CONDA=1"
if defined NEED_DASH set "NEED_CONDA=1"

if not defined NEED_CONDA goto :after_conda
call :find_conda
if not defined CONDA_BAT (
    echo [ERREUR] conda.bat introuvable.
    echo Installez Miniconda/Anaconda ou ajoutez "condabin" au PATH.
    pause
    goto :eof
)
echo conda trouve : "%CONDA_BAT%"
:after_conda

if defined DO_ENV (
    echo.
    echo === Creation de l'environnement Py26 ===
    call "%CONDA_BAT%" env create -f Py26env.yml
)

if defined NEED_CONDA (
    echo.
    echo === Activation de Py26 ===
    call "%CONDA_BAT%" activate Py26
)

if defined DO_RASP (
    echo.
    echo === Installation du plugin Raspberry ^(unifie^) ===
    call :install_plugin RASP pymodaq_plugins_raspberry pymodaq_plugins_raspberry
)

if defined DO_ARDUINO (
    echo.
    echo === Installation du plugin Arduino ===
    call :install_plugin ARDUINO pymodaq-plugins-arduino pymodaq_plugins_arduino
    echo === Correctif bleak ^(API 'discover' requise par telemetrix-esp32^) ===
    pip install "bleak>=0.22,<1.0"
)

if defined NEED_DASH (
    echo.
    echo === Lancement du dashboard PyMoDAQ ^(creation des dossiers .pymodaq^) ===
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='SilentlyContinue'; $exe=(Get-Command dashboard -ErrorAction SilentlyContinue).Source; if(-not $exe){$exe='dashboard'}; Write-Host 'Demarrage du dashboard...'; $proc=Start-Process $exe -PassThru; $u=Join-Path $env:USERPROFILE '.pymodaq'; $p='C:\ProgramData\.pymodaq'; $deadline=(Get-Date).AddMinutes(5); $seen=$null; while((Get-Date) -lt $deadline){ Start-Sleep -Seconds 2; $hf=(Test-Path $u) -and (Test-Path $p); if($hf -and -not $seen){$seen=Get-Date}; $w=Get-Process | Where-Object {$_.MainWindowTitle -match 'PyMoDAQ'}; if($hf -and $w){Write-Host 'Dashboard pret, fermeture dans 5s...'; Start-Sleep -Seconds 5; break}; if($hf -and $seen -and ((Get-Date)-$seen).TotalSeconds -gt 40){Write-Host 'Dossiers .pymodaq crees, fermeture du dashboard...'; break} }; if($proc){ taskkill /PID $proc.Id /T /F | Out-Null }; Get-Process | Where-Object {$_.MainWindowTitle -match 'PyMoDAQ'} | ForEach-Object { taskkill /PID $_.Id /T /F | Out-Null }; Write-Host 'Dashboard ferme.'"
) else (
    if defined WANT_COPY echo .pymodaq deja present : pas besoin de lancer le dashboard.
)

if defined DO_CFG call :copy_cfg

if defined DO_PRESET (
    echo.
    echo === Copie des fichiers de preset ^(.xml^) ===
    if not exist "C:\ProgramData\.pymodaq\preset_configs" mkdir "C:\ProgramData\.pymodaq\preset_configs"
    call :copyfile "Raspberry.xml" "C:\ProgramData\.pymodaq\preset_configs"
    call :copyfile "Arduino.xml"   "C:\ProgramData\.pymodaq\preset_configs"
)

echo.
echo === Termine ===
pause
goto :eof

:install_plugin
REM %1 = cle (RASP, ARDUINO), %2 = dossier des sources dans files, %3 = nom du paquet PyPI
call set "SRC=%%SRC_%~1%%"
call set "LOCALV=%%LOCAL_%~1%%"
call set "PYPIV=%%PYPI_%~1%%"
if /i "%SRC%"=="PYPI" goto :install_pypi
echo   source : copie locale files\%~2, version %LOCALV%
if "%LOCALV%"=="?" set "LOCALV=0.0.0"
REM Sources sans .git : la version est fournie a hatch-vcs, sinon pip echoue
REM ("metadata-generation-failed")
set "SETUPTOOLS_SCM_PRETEND_VERSION=%LOCALV%"
pip install -e "%~2"
set "SETUPTOOLS_SCM_PRETEND_VERSION="
goto :eof
:install_pypi
echo   source : PyPI, version %PYPIV%
pip install "%~3==%PYPIV%"
goto :eof

:srctext
REM Texte de la source d'un plugin dans le menu (T_<cle>)
call set "SRCT=%%SRC_%1%%"
call set "LV=%%LOCAL_%1%%"
call set "PV=%%PYPI_%1%%"
call set "NW=%%NEWER_%1%%"
if /i "%SRCT%"=="PYPI" ( set "T_%1=source PyPI %PV% (non testee avec ce package)" & goto :eof )
if "%PV%"=="-" ( set "T_%1=source locale %LV% (PyPI injoignable)" & goto :eof )
if defined NW ( set "T_%1=source locale %LV% (PyPI %PV% disponible)" & goto :eof )
set "T_%1=source locale %LV% (PyPI %PV%, pas plus recente)"
goto :eof

:togglesrc
REM Le choix PyPI n'existe que si PyPI publie une version plus recente
call set "NW=%%NEWER_%1%%"
if not defined NW goto :eof
call set "SRCT=%%SRC_%1%%"
if /i "%SRCT%"=="PYPI" (set "SRC_%1=LOCAL") else (set "SRC_%1=PYPI")
goto :eof

:copy_cfg
echo.
echo === Copie des fichiers de configuration ^(.toml^) ===
if not exist "%USERPROFILE%\.pymodaq" mkdir "%USERPROFILE%\.pymodaq"
if defined DO_CFGTEST (
    echo   TOML Raspberry de test : simulation sur ce PC ^(lancer src_raspberry\main.py^)
    call :copyas "pymodaq_plugins_raspberry\src\pymodaq_plugins_raspberry\resources\config_demo.toml" "%USERPROFILE%\.pymodaq\config_raspberry.toml"
) else (
    call :copyfile "config_raspberry.toml" "%USERPROFILE%\.pymodaq"
)
call :copyfile "config_arduino.toml" "%USERPROFILE%\.pymodaq"
goto :eof

:mark
if defined DO_%1 (set "S_%1=X") else (set "S_%1= ")
goto :eof

:toggle
if defined DO_%1 (set "DO_%1=") else (set "DO_%1=1")
goto :eof

:selectall
set "DO_ENV=%1"
set "DO_RASP=%1"
set "DO_ARDUINO=%1"
set "DO_CFG=%1"
set "DO_PRESET=%1"
REM Le TOML de test reste un choix explicite : il n'est jamais coche par "A"
set "DO_CFGTEST="
goto :eof

:find_conda
set "CONDA_BAT="
for /f "delims=" %%I in ('where conda.bat 2^>nul') do if not defined CONDA_BAT set "CONDA_BAT=%%I"
if defined CONDA_BAT goto :eof
if defined CONDA_EXE for %%I in ("%CONDA_EXE%") do if exist "%%~dpI..\condabin\conda.bat" set "CONDA_BAT=%%~dpI..\condabin\conda.bat"
if defined CONDA_BAT goto :eof
for %%P in (
  "%USERPROFILE%\miniconda3"
  "%USERPROFILE%\anaconda3"
  "%USERPROFILE%\Miniconda3"
  "%USERPROFILE%\Anaconda3"
  "%LOCALAPPDATA%\miniconda3"
  "%LOCALAPPDATA%\anaconda3"
  "C:\ProgramData\miniconda3"
  "C:\ProgramData\anaconda3"
  "C:\miniconda3"
  "C:\anaconda3"
) do if not defined CONDA_BAT if exist "%%~P\condabin\conda.bat" set "CONDA_BAT=%%~P\condabin\conda.bat"
goto :eof

:copyfile
if exist "%~1" (
    copy /Y "%~1" "%~2\" >nul
    echo   [OK] %~1 -^> %~2
) else (
    echo   [ATTENTION] fichier introuvable : %~1
)
goto :eof

:copyas
if exist "%~1" (
    copy /Y "%~1" "%~2" >nul
    echo   [OK] %~1 -^> %~2
) else (
    echo   [ATTENTION] fichier introuvable : %~1
)
goto :eof
