========================================================================
 Package d'installation - Plugins PyMoDAQ DAP (Raspberry unifie + Arduino)
========================================================================

CE QUE FAIT CE PACKAGE
----------------------
Le script "Install.bat" installe automatiquement :
  - l'environnement conda "Py26" (depuis files/Py26env.yml) ;
  - le plugin Raspberry unifie et le plugin Arduino, depuis les sources fournies
    dans files/ (pip install -e) ou, au choix, depuis PyPI (voir plus bas) ;
  - les fichiers de configuration (.toml) dans %USERPROFILE%\.pymodaq ;
  - les presets (.xml) dans C:\ProgramData\.pymodaq\preset_configs.

AVANT DE LANCER
---------------
1. Decompressez TOUT le zip dans un dossier (n'importe ou, chemin court conseille).
2. Fermez PyMoDAQ s'il est ouvert.
3. (Recommande) Editez les fichiers du sous-dossier "files" selon votre materiel :
     - files/config_raspberry.toml et files/config_arduino.toml
       -> remplacez les adresses IP (et les broches si besoin) par les votres ;
     - files/Raspberry.xml et files/Arduino.xml (presets) -> adaptez l'IP si besoin.

INSTALLATION
------------
- Double-cliquez sur "Install.bat".
- Un menu permet de (de)cocher les actions ; appuyez sur G pour lancer.
- Prerequis : Miniconda ou Anaconda installe (commande "conda").

  1. Environnement Py26
  2. Installation du plugin Raspberry
  3. Installation du plugin Arduino
  4. Copie des fichiers de configuration (.toml)
  5. ... avec le TOML Raspberry de TEST a la place de files/config_raspberry.toml :
     configuration de simulation (127.0.0.1) livree avec le plugin
     (src/pymodaq_plugins_raspberry/resources/config_demo.toml). Non coche par
     defaut, ni par "A".
  6. Copie des presets (.xml)

VERSION DES PLUGINS : COPIE LOCALE OU PyPI
------------------------------------------
Au lancement, Install.bat compare la version de chaque plugin fournie dans files/
(fichier version.json) a la derniere version publiee sur PyPI, et l'affiche dans
le menu.
  - Par defaut, c'est TOUJOURS la copie locale qui est installee : c'est la version
    testee avec les presets et les configurations de ce package.
  - Si PyPI publie une version plus recente, une ligne supplementaire apparait
    (R pour Raspberry, D pour Arduino) pour choisir PyPI a la place. Attention :
    une version PyPI peut ne pas contenir les fonctionnalites DAP (ex. FanHeater
    pour Arduino) et casser les presets.
  - Si PyPI n'est pas plus recente, ou injoignable (pas d'Internet), seule la
    copie locale est proposee.

TESTER SANS RASPBERRY (MODE SIMULATION)
---------------------------------------
Cochez 5 a l'installation, puis :
  - lancez le serveur de la carte sur ce PC, dans l'environnement Py26 :
      cd files\pymodaq_plugins_raspberry\src_raspberry
      python main.py
  - lancez le Dashboard PyMoDAQ et chargez le preset Raspberry.
Les temperatures simulees reagissent a la resistance et au ventilateur.
Details : files\pymodaq_plugins_raspberry\src_raspberry\README.md

REMARQUES
---------
- Les sources fournies ne contiennent pas de dossier .git : Install.bat donne
  lui-meme leur version a pip, lue dans version.json (sinon l'installation echoue
  avec "metadata-generation-failed").
- Le preset "Raspberry.xml" a ete adapte depuis l'ancien preset Raspberry Pi 3
  vers le plugin unifie (classes MoveRasp / ViewRasp). En cas de probleme,
  recreez-le (Preset Mode -> New preset -> DAQ_Move MoveRasp + DAQ_Viewer ViewRasp).

CONTENU
-------
  Install.bat              ce lanceur (double-clic)
  README.txt               ce fichier
  files/
    check_versions.ps1           comparaison des versions locales et PyPI
    Py26env.yml                  environnement conda
    config_raspberry.toml        config exemple (plugin Raspberry unifie)
    config_arduino.toml          config exemple (plugin Arduino)
    Raspberry.xml                preset
    Arduino.xml                  preset
    pymodaq_plugins_raspberry/   sources du plugin Raspberry unifie
    pymodaq-plugins-arduino/     sources du plugin Arduino
