========================================================================
 Package d'installation - Serveur Raspberry DAP (pymodaq_plugins_raspberry)
========================================================================

CE QUE FAIT CE PACKAGE
----------------------
Installe sur le Raspberry Pi le serveur que le plugin PyMoDAQ interroge par le
reseau (dossier src_raspberry du plugin), et le fait demarrer avec la carte :
  - paquets systeme (python3-venv, i2c-tools, pigpio) ;
  - activation du bus I2C et du demon pigpiod (pilotage des GPIO) ;
  - copie du serveur dans /opt/pymodaq-raspberry, environnement Python dedie ;
  - service systemd "pymodaq-raspberry" : demarre au boot, relance en cas d'arret.

PREREQUIS
---------
- Raspberry Pi (teste pour le Pi 3) avec Raspberry Pi OS 64 bits, acces SSH.
- Connexion Internet pendant l'installation (paquets systeme et Python).

INSTALLATION
------------
1. Copier le dossier sur la carte, par exemple depuis le PC :
       scp -r install-dap-raspberry <utilisateur>@<ip-du-raspberry>:~
   (ou copier le zip sur une cle USB puis : unzip install-dap-raspberry.zip)
2. Sur la carte :
       cd ~/install-dap-raspberry
       sudo bash install.sh
3. A la fin, le script affiche l'adresse IP de la carte. Cote PC, la reporter dans
   %USERPROFILE%\.pymodaq\config_raspberry.toml :
       address_Rasp = '<ip affichee>'
       port = '5555'
4. Si le script le demande (premiere activation de l'I2C) : sudo reboot

Options : sudo bash install.sh --help
  --port <n>       autre port d'ecoute (a reporter dans le TOML cote PC)
  --user <compte>  compte qui execute le serveur (defaut : celui qui lance sudo)
  --no-autostart   pas de demarrage automatique au boot

SANS DROITS ADMINISTRATEUR
--------------------------
    bash install.sh
Installe le serveur dans ~/pymodaq-raspberry et le fait demarrer au boot avec la
crontab de l'utilisateur. Rien n'est modifie sur le systeme : si l'I2C ou pigpiod
ne sont pas deja actives, le serveur fonctionne en simulation pour la partie
concernee.

UTILISATION
-----------
    sudo systemctl status pymodaq-raspberry     etat du serveur
    journalctl -u pymodaq-raspberry -f          journal en direct
    sudo systemctl restart pymodaq-raspberry    relancer (apres modif de config.py)
    sudo systemctl stop pymodaq-raspberry       arreter

Le banc (capteurs, broches) est decrit dans /opt/pymodaq-raspberry/config.py.
Relancer l'installation (mise a jour) conserve ce fichier s'il a ete modifie ;
la nouvelle version est alors deposee a cote (config.py.new).

MODE SIMULATION
---------------
Si aucun capteur ne repond sur le bus I2C (banc non branche), le serveur passe
automatiquement en simulation : temperatures et humidite simulees, qui reagissent
a la resistance et au ventilateur. Le journal l'indique par un avertissement
("Bascule en simulation automatique"). Pratique pour tester sans le banc.

ANCIENNE INSTALLATION MANUELLE
------------------------------
Si l'ancien service "pilotage.service" (procedure manuelle du wiki) est present,
il est arrete et desactive, car il utilise le meme port. Pour le reactiver :
    sudo systemctl enable --now pilotage.service

DESINSTALLATION
---------------
    sudo bash uninstall.sh          (bash uninstall.sh pour une installation utilisateur)
Arrete le serveur, retire le demarrage automatique et, apres confirmation,
supprime le dossier d'installation. Les paquets systeme et l'I2C sont conserves.

CONTENU
-------
  install.sh                       installation
  uninstall.sh                     desinstallation
  README.txt                       ce fichier
  files/
    pymodaq-raspberry.service      modele du service systemd
    src_raspberry/                 serveur (copie du plugin pymodaq_plugins_raspberry)
