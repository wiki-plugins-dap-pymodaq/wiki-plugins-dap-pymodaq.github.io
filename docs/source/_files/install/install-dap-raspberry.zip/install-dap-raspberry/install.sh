#!/usr/bin/env bash
# ============================================================================
#  Installation rapide du serveur Raspberry DAP (pymodaq_plugins_raspberry)
#
#  Usage :  sudo bash install.sh [options]   (recommande : installation complete)
#           bash install.sh [options]        (sans droits administrateur)
#
#  Options :
#    --port <n>       port d'ecoute du serveur (5555 par defaut)
#    --user <compte>  compte qui execute le serveur (defaut : celui qui lance
#                     l'installation ; root si l'installation est lancee en root)
#    --dir <chemin>   dossier d'installation (defaut : /opt/pymodaq-raspberry en
#                     administrateur, ~/pymodaq-raspberry sinon)
#    --no-autostart   installe sans demarrage automatique au boot
#    -h, --help       affiche cette aide
# ============================================================================
set -eu

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$HERE/files/src_raspberry"
SERVICE_NAME="pymodaq-raspberry"
PORT=5555
RUN_USER=""
DIR=""
AUTOSTART=1

info() { printf '\n=== %s ===\n' "$*"; }
ok()   { printf '  [OK] %s\n' "$*"; }
warn() { printf '  [ATTENTION] %s\n' "$*"; }
fail() { printf '  [ERREUR] %s\n' "$*" >&2; exit 1; }
usage() { sed -n '3,15p' "$0" | sed 's/^# \{0,1\}//'; }

while [ $# -gt 0 ]; do
    case "$1" in
        --port) PORT="${2:-}"; shift 2 ;;
        --user) RUN_USER="${2:-}"; shift 2 ;;
        --dir)  DIR="${2:-}"; shift 2 ;;
        --no-autostart) AUTOSTART=0; shift ;;
        -h|--help) usage; exit 0 ;;
        *) usage; fail "option inconnue : $1" ;;
    esac
done
case "$PORT" in ''|*[!0-9]*) fail "port invalide : '$PORT'" ;; esac
[ -f "$SRC/main.py" ] || fail "sources introuvables ($SRC/main.py) : decompressez tout le zip"

# --- Mode, compte et dossier ------------------------------------------------
if [ "$(id -u)" -eq 0 ]; then ADMIN=1; else ADMIN=0; fi
if [ -z "$RUN_USER" ]; then
    if [ "$ADMIN" -eq 1 ]; then RUN_USER="${SUDO_USER:-root}"; else RUN_USER="$(id -un)"; fi
fi
id "$RUN_USER" >/dev/null 2>&1 || fail "compte inconnu : $RUN_USER"
if [ "$ADMIN" -eq 0 ] && [ "$RUN_USER" != "$(id -un)" ]; then
    fail "sans droits administrateur, le serveur ne peut tourner que sous votre compte ($(id -un))"
fi
RUN_HOME="$(getent passwd "$RUN_USER" | cut -d: -f6)"
[ -n "$RUN_HOME" ] || RUN_HOME="$HOME"
if [ -z "$DIR" ]; then
    if [ "$ADMIN" -eq 1 ]; then DIR="/opt/$SERVICE_NAME"; else DIR="$RUN_HOME/$SERVICE_NAME"; fi
fi

MODEL="$( { tr -d '\0' < /proc/device-tree/model; } 2>/dev/null || true)"
info "Installation du serveur Raspberry DAP"
echo "  carte   : ${MODEL:-inconnue, pas un Raspberry ?}"
if [ "$ADMIN" -eq 1 ]; then
    echo "  mode    : administrateur (installation complete, service systemd)"
else
    echo "  mode    : utilisateur sans droits (ni paquets systeme, ni I2C, ni pigpiod)"
fi
echo "  compte  : $RUN_USER"
echo "  dossier : $DIR"
echo "  port    : $PORT"

# --- Systeme : paquets, I2C, pigpiod (administrateur uniquement) ---------------
if [ "$ADMIN" -eq 1 ]; then
    info "Paquets systeme"
    export DEBIAN_FRONTEND=noninteractive
    apt-get update || warn "apt-get update a echoue (pas d'Internet ?)"
    apt-get install -y python3-venv python3-pip i2c-tools || fail "installation des paquets systeme impossible"
    ok "python3-venv, python3-pip, i2c-tools"
    if apt-get install -y pigpio; then
        ok "pigpio"
    else
        warn "pigpio indisponible sur ce systeme : les actionneurs fonctionneront en simulation"
    fi

    info "Bus I2C"
    if command -v raspi-config >/dev/null 2>&1; then
        if raspi-config nonint do_i2c 0; then ok "I2C active"; else warn "activation de l'I2C impossible"; fi
    else
        warn "raspi-config absent : activez l'I2C a la main (sinon capteurs en simulation)"
    fi
    if [ "$RUN_USER" != "root" ]; then
        for group in i2c gpio; do
            if getent group "$group" >/dev/null 2>&1; then usermod -aG "$group" "$RUN_USER"; fi
        done
        ok "$RUN_USER ajoute aux groupes i2c et gpio"
    fi

    info "Demon pigpiod (pilotage des GPIO)"
    if systemctl enable --now pigpiod >/dev/null 2>&1; then
        ok "pigpiod demarre et active au boot"
    else
        warn "pigpiod n'a pas pu demarrer : les actionneurs fonctionneront en simulation"
    fi

    # L'ancienne procedure du wiki installait "pilotage.service" sur le meme port
    if systemctl is-enabled pilotage.service >/dev/null 2>&1 || systemctl is-active pilotage.service >/dev/null 2>&1; then
        info "Ancien service pilotage.service"
        systemctl disable --now pilotage.service >/dev/null 2>&1 || true
        warn "pilotage.service (ancienne installation manuelle) arrete et desactive : il occupait le meme port"
        echo "      Pour le reactiver : sudo systemctl enable --now pilotage.service"
    fi
else
    info "Verifications (sans droits administrateur)"
    if [ -e /dev/i2c-1 ]; then ok "bus I2C disponible"; else warn "bus I2C absent (/dev/i2c-1) : capteurs en simulation"; fi
    if pgrep -x pigpiod >/dev/null 2>&1; then ok "pigpiod en marche"; else warn "pigpiod arrete : actionneurs en simulation"; fi
fi

# --- Copie du serveur -----------------------------------------------------------
info "Copie du serveur"
mkdir -p "$DIR"
KEEP_CONFIG=0
if [ -f "$DIR/config.py" ] && ! cmp -s "$DIR/config.py" "$SRC/config.py"; then
    KEEP_CONFIG=1
    cp "$DIR/config.py" "$DIR/config.py.keep"
fi
cp -r "$SRC/." "$DIR/"
find "$DIR" -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true
if [ "$KEEP_CONFIG" -eq 1 ]; then
    cp "$SRC/config.py" "$DIR/config.py.new"
    mv "$DIR/config.py.keep" "$DIR/config.py"
    warn "config.py existant conserve (description de votre banc) ; nouvelle version : config.py.new"
fi
ok "$DIR"

# --- Environnement Python ---------------------------------------------------------
info "Environnement Python"
python3 -m venv "$DIR/.venv" || fail "python3 -m venv a echoue (paquet python3-venv manquant ?)"
"$DIR/.venv/bin/python" -m pip install --upgrade pip >/dev/null 2>&1 || warn "mise a jour de pip impossible"
"$DIR/.venv/bin/python" -m pip install -r "$DIR/requirements.txt" \
    || fail "installation des dependances Python impossible (Internet ?)"
ok "dependances installees (requirements.txt)"
if [ "$ADMIN" -eq 1 ] && [ "$RUN_USER" != "root" ]; then
    chown -R "$RUN_USER": "$DIR"
fi

# --- Demarrage automatique -------------------------------------------------------
if [ "$AUTOSTART" -eq 1 ]; then
    if [ "$ADMIN" -eq 1 ]; then
        info "Service systemd $SERVICE_NAME"
        sed -e "s|@USER@|$RUN_USER|g" -e "s|@DIR@|$DIR|g" -e "s|@PORT@|$PORT|g" \
            "$HERE/files/$SERVICE_NAME.service" > "/etc/systemd/system/$SERVICE_NAME.service"
        systemctl daemon-reload
        systemctl enable "$SERVICE_NAME" >/dev/null 2>&1
        systemctl restart "$SERVICE_NAME"
        sleep 3
        if systemctl is-active --quiet "$SERVICE_NAME"; then
            ok "service demarre, et relance a chaque demarrage de la carte"
        else
            warn "le service ne tourne pas. Dernieres lignes du journal :"
            journalctl -u "$SERVICE_NAME" -n 20 --no-pager || true
        fi
    else
        info "Demarrage automatique (crontab @reboot)"
        START="cd '$DIR' && '$DIR/.venv/bin/python' main.py --port $PORT >> '$DIR/serveur.log' 2>&1"
        { crontab -l 2>/dev/null | grep -v "# $SERVICE_NAME\$" || true
          echo "@reboot $START  # $SERVICE_NAME"; } | crontab -
        ok "le serveur demarrera avec la carte"
        pkill -f "$DIR/.venv/bin/python main.py" 2>/dev/null || true
        (cd "$DIR" && nohup "$DIR/.venv/bin/python" main.py --port "$PORT" >> "$DIR/serveur.log" 2>&1 &)
        sleep 3
        if pgrep -f "$DIR/.venv/bin/python main.py" >/dev/null 2>&1; then
            ok "serveur demarre (journal : $DIR/serveur.log)"
        else
            warn "le serveur ne tourne pas. Dernieres lignes de $DIR/serveur.log :"
            tail -n 20 "$DIR/serveur.log" 2>/dev/null || true
        fi
    fi
fi

# --- Resume ---------------------------------------------------------------------
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
info "Termine"
echo "  Cote PC, dans %USERPROFILE%\\.pymodaq\\config_raspberry.toml :"
echo "      address_Rasp = '${IP:-<adresse IP de la carte>}'"
echo "      port = '$PORT'"
echo
if [ "$ADMIN" -eq 1 ]; then
    echo "  Etat du serveur   : sudo systemctl status $SERVICE_NAME"
    echo "  Journal en direct : journalctl -u $SERVICE_NAME -f"
    echo "  Arreter/relancer  : sudo systemctl stop|restart $SERVICE_NAME"
    if [ ! -e /dev/i2c-1 ]; then
        echo
        warn "le bus I2C ne sera disponible qu'apres un redemarrage : sudo reboot"
    fi
else
    echo "  Journal           : tail -f $DIR/serveur.log"
    echo "  Arreter           : pkill -f '$DIR/.venv/bin/python main.py'"
fi
echo "  Description du banc (capteurs, broches) : $DIR/config.py"
