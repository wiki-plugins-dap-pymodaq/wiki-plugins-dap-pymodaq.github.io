#!/usr/bin/env bash
# ============================================================================
#  Desinstallation du serveur Raspberry DAP (pymodaq_plugins_raspberry)
#
#  Usage :  sudo bash uninstall.sh [--dir <chemin>] [--yes]
#           bash uninstall.sh [--dir <chemin>] [--yes]   (installation utilisateur)
#
#  Arrete le serveur, retire son demarrage automatique, puis supprime le dossier
#  d'installation (apres confirmation, sauf avec --yes). Les paquets systeme
#  (pigpio, i2c-tools...) et l'activation de l'I2C sont conserves.
# ============================================================================
set -eu

SERVICE_NAME="pymodaq-raspberry"
DIR=""
YES=0

while [ $# -gt 0 ]; do
    case "$1" in
        --dir) DIR="${2:-}"; shift 2 ;;
        --yes) YES=1; shift ;;
        -h|--help) sed -n '3,10p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *) echo "option inconnue : $1" >&2; exit 1 ;;
    esac
done

if [ "$(id -u)" -eq 0 ]; then ADMIN=1; else ADMIN=0; fi
if [ -z "$DIR" ]; then
    if [ "$ADMIN" -eq 1 ]; then DIR="/opt/$SERVICE_NAME"; else DIR="$HOME/$SERVICE_NAME"; fi
fi

echo "=== Desinstallation du serveur Raspberry DAP ($DIR) ==="

if [ "$ADMIN" -eq 1 ] && [ -f "/etc/systemd/system/$SERVICE_NAME.service" ]; then
    systemctl disable --now "$SERVICE_NAME" >/dev/null 2>&1 || true
    rm -f "/etc/systemd/system/$SERVICE_NAME.service"
    systemctl daemon-reload
    echo "  [OK] service $SERVICE_NAME arrete et supprime"
fi

if crontab -l 2>/dev/null | grep -q "# $SERVICE_NAME\$"; then
    { crontab -l 2>/dev/null | grep -v "# $SERVICE_NAME\$" || true; } | crontab -
    echo "  [OK] demarrage automatique (crontab) retire"
fi
pkill -f "$DIR/.venv/bin/python main.py" 2>/dev/null && echo "  [OK] serveur arrete" || true

if [ -d "$DIR" ]; then
    if [ "$YES" -eq 0 ]; then
        printf "  Supprimer %s (y compris config.py, la description de votre banc) ? [o/N] " "$DIR"
        read -r answer
        case "$answer" in o|O|oui|OUI|y|Y) ;; *) echo "  Dossier conserve."; exit 0 ;; esac
    fi
    rm -rf "$DIR"
    echo "  [OK] $DIR supprime"
fi
echo "=== Termine ==="
